rootProject.name = "Lab_7_210042150"

